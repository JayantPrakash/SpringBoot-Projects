package com.springboot.mvcvalidation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MvcvalidationApplication {

	public static void main(String[] args) {
		SpringApplication.run(MvcvalidationApplication.class, args);
	}

}
